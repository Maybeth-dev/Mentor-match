const MySessions = () => {
  return (
    <div>
      <h2 className="text-xl font-semibold mb-2">My Sessions</h2>
      <p className="text-gray-500">No sessions booked.</p>
    </div>
  );
};

export default MySessions;
