const MyRequests = () => {
  return (
    <div>
      <h2 className="text-xl font-semibold mb-2">My Requests</h2>
      <p className="text-gray-500">No requests yet.</p>
    </div>
  );
};

export default MyRequests;
