 import { Routes, Route } from "react-router-dom";
import HomePage from "./Pages/Homepage";
import Login from "./Pages/Login";
import  Signup from "./Pages/Signup";
import DashboardRedirect from "./Pages/DashboardRedirect";
import PrivateRoute from "./routes/PrivateRoute";
import MenteeProfile  from "./Pages/MenteeProfile";
import RoleGuard from "./routes/RoleGuard"; 
import MentorProfile from "./Pages/MentorProfile";

function App() {
  return (
    <Routes>
      <Route path="/" element={<HomePage />} />
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Signup />} />
      <Route path="/dashboard" element={
           <PrivateRoute>
            <DashboardRedirect />
           </PrivateRoute>
        }
      />
      <Route
        path="/mentee"
        element={
          <PrivateRoute>
            <MenteeProfile />
          </PrivateRoute>
        }
      />
      <Route
  path="/mentee"
  element={
    <RoleGuard allowedRoles={["mentee"]}>
      <MenteeProfile />
    </RoleGuard>
  }
/>

<Route
  path="/mentor"
  element={
    <RoleGuard allowedRoles={["mentor"]}>
      <MentorProfile />
    </RoleGuard>
  }
/>
    </Routes>
  );
}

export default App;
