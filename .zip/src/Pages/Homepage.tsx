 import React from "react"; 
 import Header from "../Components/header";
import { Link } from "react-router-dom";

const HomePage = () => {
  return (
    <div className="bg-white min-h-screen">
      <Header />
      <section className="text-center py-20">
        <p className="text-sm text-blue-500 uppercase font-semibold">A Social Platform for Learners</p>
        <h1 className="text-5xl font-bold mt-4 mb-2">Connect & learn from the experts</h1>
        <p className="text-gray-600 mb-8">Grow your career fast with the right mentor.</p>
        <Link to="/dashboard" className="bg-yellow-400 text-black px-6 py-3 rounded-full font-medium hover:bg-yellow-300">
          Go to Dashboard
        </Link>
        <div className="mt-12">
          <img src="https://images.unsplash.com/photo-1504384308090-c894fdcc538d" alt="Mentorship" className="w-full max-w-2xl mx-auto rounded-lg shadow-lg" />
        </div>
        <div className="flex justify-center gap-6 mt-16 flex-wrap">
          <div className="text-center">
            <img src="https://randomuser.me/api/portraits/men/32.jpg" className="w-20 h-20 rounded-full mx-auto mb-2" />
            <p className="text-sm font-semibold">Active Professionals</p>
            <p className="text-xl font-bold">10,422</p>
          </div>
          <div className="text-center">
            <img src="https://randomuser.me/api/portraits/women/44.jpg" className="w-20 h-20 rounded-full mx-auto mb-2" />
            <p className="text-sm font-semibold">Online Courses</p>
            <p className="text-xl font-bold">2,570</p>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;
